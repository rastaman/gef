/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: AudioClip.java,v $
   Revision 1.2  2005/01/05 09:22:23  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/03/22 15:28:51  bobintetley
   Complete stub Applet implementation


*/

package swingwt.applet;

public interface AudioClip {
    void play();
    void loop();
    void stop();
}
