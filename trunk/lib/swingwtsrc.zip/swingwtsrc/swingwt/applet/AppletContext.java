/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: AppletContext.java,v $
   Revision 1.2  2005/01/05 09:22:23  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/03/22 15:28:51  bobintetley
   Complete stub Applet implementation


*/

package swingwt.applet;

import java.util.*;
import java.net.*;
import java.io.*;
import swingwt.awt.*;

public interface AppletContext {
    
    AudioClip getAudioClip(URL url);
    Image getImage(URL url);
    Applet getApplet(String name);
    Enumeration getApplets();
    void showDocument(URL url);
    public void showDocument(URL url, String target);
    void showStatus(String status);
    public void setStream(String key, InputStream stream)throws IOException;
    public InputStream getStream(String key);
    public Iterator getStreamKeys();
}

