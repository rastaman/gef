/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: ScrollPane.java,v $
   Revision 1.6  2005/01/05 09:22:25  bobintetley
   Updated copyright year on source

   Revision 1.5  2004/01/20 07:38:05  bobintetley
   Bug fixes and compatibility methods

   Revision 1.4  2004/01/15 10:11:14  bobintetley
   Fixed AWT constructors/hierarchy

   Revision 1.3  2003/12/14 09:13:38  bobintetley
   Added CVS log to source headers

*/

package swingwt.awt;

public class ScrollPane extends swingwtx.swing.JScrollPane {
    
    public static final int SCROLLBARS_AS_NEEDED = 0;
    public static final int SCROLLBARS_AS_ALWAYS = 1;
    public static final int SCROLLBARS_AS_NEVER = 2;
    public ScrollPane() { super(); }
    public ScrollPane(Component component) { super(component); }
    public ScrollPane(int displayPolicy) { super(); }
    public ScrollPane(int vsbPolicy, int hsbPolicy) { super(vsbPolicy, hsbPolicy); }
    public ScrollPane(Component component, int vsbPolicy, int hsbPolicy) { super(component, vsbPolicy, hsbPolicy); }
}
