/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: List.java,v $
   Revision 1.6  2005/01/05 09:22:25  bobintetley
   Updated copyright year on source

   Revision 1.5  2004/03/21 17:22:53  bobintetley
   Compatibility methods for awt Graphics, List and Label. Dummy Applet implementation

   Revision 1.4  2004/01/15 10:11:14  bobintetley
   Fixed AWT constructors/hierarchy

   Revision 1.3  2003/12/14 09:13:38  bobintetley
   Added CVS log to source headers

*/

package swingwt.awt;

public class List extends swingwtx.swing.JList {

    public List() { super(); }
    public List(Object[] items) { super(items); }
    public List(java.util.Vector items) { super(items); }
    public List(int rows) { super(); }
    public List(int rows, boolean multipleMode) { super(); }
    
    public void add(String item) {
        super.addItem(item);
    }
    
    public int countItems() {
        return super.getItemCount();    
    }
    
    public String getItem(int index) {
        return super.getItemAt(index).toString();    
    }
    
    public void select(int index) {
        super.setSelectedIndex(index);
    }
    
    public void remove(String item) {
        super.removeItem(item);
    }
    
    public void remove(int index) {
        super.removeItemAt(index);
    }
    
    public void removeAll() {
        super.removeAllItems();
    }
    
    public void replaceItem(String item, int index) {
        super.replaceItemAt(item, index);
    }

}
