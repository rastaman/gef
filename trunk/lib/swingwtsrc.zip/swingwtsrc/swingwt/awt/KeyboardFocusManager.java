/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: KeyboardFocusManager.java,v $
   Revision 1.5  2005/01/05 09:22:25  bobintetley
   Updated copyright year on source

   Revision 1.4  2005/01/05 08:37:11  bobintetley
   Many compatibility fixes from David Barron

   Revision 1.3  2004/10/30 20:11:54  bobintetley
   Code cleanup

   Revision 1.2  2003/12/14 09:13:38  bobintetley
   Added CVS log to source headers

*/
package swingwt.awt;

import java.beans.PropertyChangeListener;

import swingwtx.swing.FocusManager;


/**
 * Not nearly complete, but enough to handle focusNext/focusPrevious
 * which is enough to write your own focus manager!
 */
public abstract class KeyboardFocusManager {
    
    public KeyboardFocusManager() {}
    
    public void focusNextComponent() {  }
    public abstract void focusNextComponent(Component component);
    public void focusPreviousComponent() {  }
    public abstract void focusPreviousComponent(Component component);
    
    public static KeyboardFocusManager getCurrentKeyboardFocusManager() {
        KeyboardFocusManager manager = FocusManager.getCurrentManager();
        if (manager == null) {
            manager = new FocusManager();
            FocusManager.setCurrentManager((FocusManager)manager);
        }
        return manager;
    }

    public void addPropertyChangeListener(String property, PropertyChangeListener listener) {
        // TODO
    }

    /**
     * @param form
     */
    public void addKeyEventDispatcher(KeyEventDispatcher dispatcher)
    {
        // TODO
    }

    public Component getFocusOwner() {
        // TODO
        return null;
    }
    
}
