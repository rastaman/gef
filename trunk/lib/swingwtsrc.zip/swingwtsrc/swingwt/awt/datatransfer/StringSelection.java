/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: StringSelection.java,v $
   Revision 1.2  2005/01/05 09:22:25  bobintetley
   Updated copyright year on source

   Revision 1.1  2005/01/05 08:37:12  bobintetley
   Many compatibility fixes from David Barron

 
 */

package swingwt.awt.datatransfer;

import java.io.IOException;

public class StringSelection implements Transferable, ClipboardOwner
{

    public StringSelection(String text)
    {
        // TODO 
    }

    public DataFlavor[] getTransferDataFlavors()
    {
        // TODO
        return null;
    }

    public boolean isDataFlavorSupported(DataFlavor flavor)
    {
        // TODO
        return false;
    }

    public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException
    {
        // TODO
        return null;
    }

    public void lostOwnership(Clipboard clipboard, Transferable contents)
    {
        // TODO
    }

}
