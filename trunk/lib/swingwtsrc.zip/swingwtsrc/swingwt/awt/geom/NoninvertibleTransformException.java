/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: NoninvertibleTransformException.java,v $
   Revision 1.2  2005/01/05 09:22:27  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/01/15 15:20:29  bobintetley
   Java2D work


*/

package swingwt.awt.geom;

public class NoninvertibleTransformException extends java.lang.Exception {
    public NoninvertibleTransformException(String s) {
        super (s);
    }
}