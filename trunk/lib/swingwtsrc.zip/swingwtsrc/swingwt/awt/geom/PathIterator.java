/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: PathIterator.java,v $
   Revision 1.2  2005/01/05 09:22:27  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/01/15 15:20:29  bobintetley
   Java2D work


*/

package swingwt.awt.geom;

public interface PathIterator {
  
    public static final int WIND_EVEN_ODD	= 0;
    public static final int WIND_NON_ZERO	= 1;
    public static final int SEG_MOVETO		= 0;
    public static final int SEG_LINETO		= 1;
    public static final int SEG_QUADTO		= 2;
    public static final int SEG_CUBICTO		= 3;
    public static final int SEG_CLOSE		= 4;
    public int getWindingRule();
    public boolean isDone();
    public void next();
    public int currentSegment(float[] coords);
    public int currentSegment(double[] coords);
}
