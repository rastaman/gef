/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: HeadlessException.java,v $
   Revision 1.5  2005/01/05 09:22:25  bobintetley
   Updated copyright year on source

   Revision 1.4  2004/05/05 12:43:19  bobintetley
   Patches/new files from Laurent Martell

   Revision 1.3  2004/03/30 10:42:44  bobintetley
   Many minor bug fixes, event improvements by Dan Naab. Full swing.Icon support

   Revision 1.2  2003/12/14 09:13:38  bobintetley
   Added CVS log to source headers

*/

package swingwt.awt;

public class HeadlessException extends UnsupportedOperationException {
    public HeadlessException() { super(); }
    public HeadlessException(String s) { super(s); }
}
