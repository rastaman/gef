/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: Button.java,v $
   Revision 1.6  2005/01/05 09:22:24  bobintetley
   Updated copyright year on source

   Revision 1.5  2004/06/11 03:29:26  dannaab
   AWT improvements: implement Button over JButton; Menu fixes; add missing geom me
   thods; add some missing awt event methods/features

   Revision 1.4  2004/01/15 10:11:14  bobintetley
   Fixed AWT constructors/hierarchy

   Revision 1.3  2003/12/14 09:13:38  bobintetley
   Added CVS log to source headers

*/

package swingwt.awt;

import swingwtx.swing.JButton;

public class Button extends AWTSwingWrapper {
    
    public Button() { swingPeer = new JButton(); }
    public Button(String title) { swingPeer = new JButton(title); }
    
    private JButton getSwingPeer() { return (JButton) swingPeer; }
    
    public String getLabel() { return getSwingPeer().getText(); }
    public void setLabel(String label) { getSwingPeer().setText(label); }
}
