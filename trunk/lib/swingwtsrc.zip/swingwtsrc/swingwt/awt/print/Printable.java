/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: Printable.java,v $
   Revision 1.2  2005/01/05 09:22:28  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/09/24 10:56:56  bobintetley
   Mousewheel/printing stubs (David Jung)



*/
package swingwt.awt.print;

import swingwt.awt.Graphics;

/**
 * @author David Jung 
 */
public interface Printable
{
  public static int NO_SUCH_PAGE = 1;
  public static int PAGE_EXISTS = 0;

  public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException;

}
