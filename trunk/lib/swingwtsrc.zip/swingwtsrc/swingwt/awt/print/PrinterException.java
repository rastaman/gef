/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: PrinterException.java,v $
   Revision 1.2  2005/01/05 09:22:28  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/09/24 10:56:56  bobintetley
   Mousewheel/printing stubs (David Jung)



*/
package swingwt.awt.print;

import java.lang.Exception;

/**
 * @author David Jung 
 */
public class PrinterException extends Exception
{
  public PrinterException()
  {}

  public PrinterException(String msg)
  {
    super(msg);
  }
}
