/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: PrinterJob.java,v $
   Revision 1.2  2005/01/05 09:22:28  bobintetley
   Updated copyright year on source

   Revision 1.1  2003/12/15 16:22:13  bobintetley
   awt.geom/print stubs


*/

package swingwt.awt.print;

public class PrinterJob {
    
}
