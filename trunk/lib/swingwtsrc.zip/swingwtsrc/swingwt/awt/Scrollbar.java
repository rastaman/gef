/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: Scrollbar.java,v $
   Revision 1.2  2005/01/05 09:22:25  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/03/12 16:35:28  bobintetley
   AWT CheckboxGroup support and fix for incorrectly named AWT Scrollbar

   Revision 1.1  2004/01/15 10:11:14  bobintetley
   Fixed AWT constructors/hierarchy


*/

package swingwt.awt;

public class Scrollbar extends swingwtx.swing.JScrollBar {
    public Scrollbar() { super(); }
    public Scrollbar(int orientation) { super(orientation); }
    public Scrollbar(int orientation, int value, int extent, int min, int max) { super(orientation, value, extent, min, max); }
}
