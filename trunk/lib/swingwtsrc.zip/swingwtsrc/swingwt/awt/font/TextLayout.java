package swingwt.awt.font;

import java.text.AttributedCharacterIterator;
import java.util.Map;

import swingwt.awt.Font;

public class TextLayout implements Cloneable {
	// Probably this class is best implemented with the draw2d text
	// features
	
	public TextLayout(AttributedCharacterIterator text, FontRenderContext frc)  {
		
	}
	
	public TextLayout(String string, Font font, FontRenderContext frc) {
		
	}
	
	public TextLayout(String string, Map attributes, FontRenderContext frc) {
		
	}
	
	public byte getCharacterLevel(int index) {
		return 0;
	}
	
}
