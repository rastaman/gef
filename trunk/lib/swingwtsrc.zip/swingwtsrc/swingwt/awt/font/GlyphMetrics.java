/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: GlyphMetrics.java,v $
   Revision 1.5  2006/03/11 08:57:03  bobintetley
   (Scott Cytacki) Large patch containing Java2D implementation and some fixes

   Revision 1.4  2005/01/05 09:22:27  bobintetley
   Updated copyright year on source

   Revision 1.3  2004/10/30 20:11:55  bobintetley
   Code cleanup

   Revision 1.2  2004/04/21 10:44:18  bobintetley
   Code cleanup and native build script fix

   Revision 1.1  2004/01/15 15:20:29  bobintetley
   Java2D work


*/

package swingwt.awt.font;

import swingwt.awt.geom.*;

public final class GlyphMetrics {

    public static final byte STANDARD = 0;
    public static final byte LIGATURE = 1;
    public static final byte COMBINING = 2;
    public static final byte COMPONENT = 3;
    public static final byte WHITESPACE = 4;
    
    Rectangle2D bounds;
    
    public GlyphMetrics(float advance, Rectangle2D bounds, byte glyphType) {
    	this.bounds = bounds;

    }
    public GlyphMetrics(boolean horizontal, float advanceX, float advanceY,
			Rectangle2D bounds, byte glyphType) {
    	this.bounds = bounds;
	
    }
    public float getAdvance() {
        return 0;
    }
    public float getAdvanceX() {
        return 0;
    }
    public float getAdvanceY() {
        return 0;
    }
    public Rectangle2D getBounds2D() {
    	return bounds;
    }
    public float getLSB() {
        return 0;
    }
    public float getRSB() {
        return 0;
    }
    public int getType() {
        return 0;
    }
    public boolean isStandard() {
        return true;
    }
    public boolean isLigature() {
        return false;
    }
    public boolean isCombining() {
        return false;
    }
    public boolean isComponent() {
        return false;
    }
    public boolean isWhitespace() {
        return false;
    }
}


