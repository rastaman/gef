/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley
 
   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.
 
   Contact me by electronic mail: bobintetley@users.sourceforge.net
 
   $Log: DropTarget.java,v $
   Revision 1.2  2005/01/05 09:22:26  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/05/05 12:43:19  bobintetley
   Patches/new files from Laurent Martell

 
 */
package swingwt.awt.dnd;

import swingwt.awt.Component;
import swingwt.awt.HeadlessException;
import swingwt.awt.datatransfer.FlavorMap;


/** @author Laurent Martell */
public class DropTarget {
    public DropTarget() {
    }

    public DropTarget(Component c,
                      int ops,
                      DropTargetListener dtl,
                      boolean act,
                      FlavorMap fm)
        throws HeadlessException
    {
        /* TODO */
    }

    public DropTarget(Component c,
                      int ops,
                      DropTargetListener dtl,
                      boolean act)
        throws HeadlessException
    {
        /* TODO */
    }

    public DropTarget(Component c,
                      int ops,
                      DropTargetListener dtl)
        throws HeadlessException
    {
        /* TODO */
    }
}
