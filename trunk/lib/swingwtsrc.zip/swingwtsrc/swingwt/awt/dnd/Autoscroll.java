/*
   SwingWT
   Copyright(c)2003-2005, Tomer Bartletz
 
   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.
 
   Contact me by electronic mail: tomerb@users.sourceforge.net

   $Log: Autoscroll.java,v $
   Revision 1.3  2005/01/05 09:22:26  bobintetley
   Updated copyright year on source

   Revision 1.2  2003/12/22 08:48:17  bobintetley
   Fixed up DnD to build temporarily


 */
package swingwt.awt.dnd;

import swingwt.awt.Insets;

import org.eclipse.swt.graphics.Point;

/**
 * 
 * 
 * @author Tomer Barletz, tomerb@users.sourceforge.net
 * @version 0.1
 */
public interface Autoscroll {
	
	/**
	 * Returns the insets of the container
	 */
	public Insets getAutoscrollInsets();
	
	/**
 	* notify the coponent to autoscroll
 	* @param cursorLocn the location of the cursor
 	*/
	public void autoscroll(Point cursorLocn);
}
