/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley
 
   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.
 
   Contact me by electronic mail: bobintetley@users.sourceforge.net
 
   $Log: DragSourceDropEvent.java,v $
   Revision 1.2  2005/01/05 09:22:26  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/05/05 12:43:19  bobintetley
   Patches/new files from Laurent Martell

 
 */
package swingwt.awt.dnd;

/** @author Laurent Martell */
public class DragSourceDropEvent extends DragSourceEvent {

    public DragSourceDropEvent(DragSourceContext context) {
        super(context);
    }

    public DragSourceDropEvent(DragSourceContext context,
                               int action,
                               boolean success,
                               int x,
                               int y)
    {
        super(context,x,y);
    }

    public DragSourceDropEvent(DragSourceContext context,
                               int action,
                               boolean success) {
        super(context);
    }
}
