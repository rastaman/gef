/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: BufferCapabilities.java,v $
   Revision 1.4  2005/01/05 09:22:24  bobintetley
   Updated copyright year on source

   Revision 1.3  2004/06/08 09:24:21  dannaab
   Rename Component.getPeer() -> getSWTPeer().  added ComponentPeer and stubbed out support classes.

   Revision 1.2  2004/04/18 14:21:49  bobintetley
   JSpinner implementation


*/
package swingwt.awt;

/**
 * @author Daniel Spiewak
 */
public class BufferCapabilities {

	public BufferCapabilities(ImageCapabilities imageCaps, ImageCapabilities imageCaps2, Object object) {
	}

	public class FlipContents {}
}
