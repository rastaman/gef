/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net
 
   $Log: Transparency.java,v $
   Revision 1.4  2005/01/05 09:22:25  bobintetley
   Updated copyright year on source

   Revision 1.3  2004/04/29 12:49:26  bobintetley
   Additional JOptionePane constants, missing JTree methods and improved awt.Image support

   Revision 1.2  2004/01/06 08:28:02  bobintetley
   Header fixes

 
 */
package swingwt.awt;

public interface Transparency {
    public final static int OPAQUE = 1;
    public final static int BITMASK = 2;
    public final static int TRANSLUCENT = 3;
    public int getTransparency();
}