/*
   SwingWT
   Copyright(c)2003-2005, Tomer Bartletz
 
   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.
 
   Contact me by electronic mail: tomerb@users.sourceforge.net

   $Log: AWTEventMulticaster.java,v $
   Revision 1.5  2005/01/05 09:22:24  bobintetley
   Updated copyright year on source

   Revision 1.4  2004/04/16 10:19:05  dannaab
   Misc bug fixes, InputMap implementation, preliminary undo support

   Revision 1.3  2004/03/30 10:42:44  bobintetley
   Many minor bug fixes, event improvements by Dan Naab. Full swing.Icon support

   Revision 1.2  2003/12/22 08:48:17  bobintetley
   Fixed up DnD to build temporarily


 */
package swingwt.awt;

import swingwt.awt.event.*;

/**
 * 
 * 
 * @author Tomer Barletz, tomerb@users.sourceforge.net
 * @version 0.1
 */
public class AWTEventMulticaster implements ComponentListener, ContainerListener, FocusListener, KeyListener,
                                            MouseListener, MouseMotionListener, WindowListener, 
                                            WindowFocusListener, WindowStateListener, ActionListener, 
                                            ItemListener, AdjustmentListener, TextListener
                                            {

    public void actionPerformed(ActionEvent e) {
    }

    public void adjustmentValueChanged(AdjustmentEvent e) {
    }

    public void componentAdded(ContainerEvent e) {
    }

    public void componentHidden(ComponentEvent e) {
    }

    public void componentMoved(ComponentEvent e) {
    }

    public void componentRemoved(ContainerEvent e) {
    }

    public void componentResized(ComponentEvent e) {
    }

    public void componentShown(ComponentEvent e) {
    }

    public void focusGained(FocusEvent e) {
    }

    public void focusLost(FocusEvent e) {
    }

    public void itemStateChanged(ItemEvent e) {
    }

    public void keyPressed(KeyEvent e) {
    }

    public void keyReleased(KeyEvent e) {
    }

    public void keyTyped(KeyEvent e) {
    }

    public void mouseClicked(MouseEvent e) {
    }

    public void mouseDragged(MouseEvent e) {
    }

    public void mouseEntered(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }

    public void mouseMoved(MouseEvent e) {
    }

    public void mousePressed(MouseEvent e) {
    }

    public void mouseReleased(MouseEvent e) {
    }

    public void textValueChanged(TextEvent e) {
    }

    public void windowActivated(WindowEvent e) {
    }

    public void windowClosed(WindowEvent e) {
    }

    public void windowClosing(WindowEvent e) {
    }

    public void windowDeactivated(WindowEvent e) {
    }

    public void windowDeiconified(WindowEvent e) {
    }

    public void windowGainedFocus(WindowEvent e) {
    }

    public void windowIconified(WindowEvent e) {
    }

    public void windowLostFocus(WindowEvent e) {
    }

    public void windowOpened(WindowEvent e) {
    }

                                                                                                                                                    public void windowStateChanged(WindowEvent e) {
                                                                                                                                                    }

}
