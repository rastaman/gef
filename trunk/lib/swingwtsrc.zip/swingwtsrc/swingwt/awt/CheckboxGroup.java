/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

*/

package swingwt.awt;

public class CheckboxGroup extends swingwtx.swing.ButtonGroup {
    public CheckboxGroup() { super(); }

    //    public Checkbox getSelectedCheckbox() {}
    //    public synchronized void setSelectedCheckbox(Checkbox box) {}
    //    public String toString() {}
}
