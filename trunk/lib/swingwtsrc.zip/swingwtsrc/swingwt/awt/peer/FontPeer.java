/*
   SwingWT
   Copyright(c)2004, Daniel Naab

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: dannaab@users.sourceforge.net
   
   $Log: FontPeer.java,v $
   Revision 1.1  2004/06/08 09:24:22  dannaab
   Rename Component.getPeer() -> getSWTPeer().  added ComponentPeer and stubbed out support classes.

*/
package swingwt.awt.peer;

/**
 * this was a tough one....
 * @author Dan
 */
public interface FontPeer
{
}
