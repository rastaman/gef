/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: WritableRaster.java,v $
   Revision 1.2  2005/01/05 09:22:28  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/01/15 15:20:30  bobintetley
   Java2D work


*/

package swingwt.awt.image;

public class WritableRaster extends Raster {
    
}
