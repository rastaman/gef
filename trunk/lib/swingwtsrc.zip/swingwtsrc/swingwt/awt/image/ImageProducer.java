/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: ImageProducer.java,v $
   Revision 1.2  2005/01/05 09:22:27  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/04/29 12:49:26  bobintetley
   Additional JOptionePane constants, missing JTree methods and improved awt.Image support


*/

package swingwt.awt.image;

public interface ImageProducer {
    public void addConsumer(ImageConsumer ic);
    public boolean isConsumer(ImageConsumer ic);
    public void removeConsumer(ImageConsumer ic);
    public void startProduction(ImageConsumer ic);
    public void requestTopDownLeftRightResend(ImageConsumer ic);
}
