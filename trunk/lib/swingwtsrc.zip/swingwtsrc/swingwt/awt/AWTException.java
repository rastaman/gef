/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley
 
   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.
 
   Contact me by electronic mail: bobintetley@users.sourceforge.net
 
   $Log: AWTException.java,v $
   Revision 1.4  2005/01/05 09:22:24  bobintetley
   Updated copyright year on source

   Revision 1.3  2004/06/11 03:29:26  dannaab
   AWT improvements: implement Button over JButton; Menu fixes; add missing geom me
   thods; add some missing awt event methods/features

   Revision 1.2  2004/04/20 16:35:44  bobintetley
   Code cleanup

 
 */
package swingwt.awt;

/**
 * @author Daniel Spiewak
 */
public class AWTException extends Exception {
    
    public AWTException(String msg) { super(msg); } 
}
