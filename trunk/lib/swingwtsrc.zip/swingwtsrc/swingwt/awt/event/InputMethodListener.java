/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: InputMethodListener.java,v $
   Revision 1.2  2005/01/05 09:22:27  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/03/30 10:42:44  bobintetley
   Many minor bug fixes, event improvements by Dan Naab. Full swing.Icon support


*/


package swingwt.awt.event;

import java.util.EventListener;

/**
 * @author Dan Naab
 */
public interface InputMethodListener extends EventListener
{
    void inputMethodTextChanged(InputMethodEvent event);
    void caretPositionChanged(InputMethodEvent event);
}
