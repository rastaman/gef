/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.
   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: FocusListener.java,v $
   Revision 1.7  2005/01/05 09:22:27  bobintetley
   Updated copyright year on source

   Revision 1.6  2004/10/30 20:11:55  bobintetley
   Code cleanup

   Revision 1.5  2003/12/14 09:13:38  bobintetley
   Added CVS log to source headers

*/


package swingwt.awt.event;

public interface FocusListener extends EventListener {
    public void focusGained(FocusEvent e);
    public void focusLost(FocusEvent e);
}
