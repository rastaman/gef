/*
   SwingWT
   Copyright(c)2003-2005, Tomer Bartletz
 
   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.
 
   Contact me by electronic mail: tomerb@users.sourceforge.net

   $Log: MouseMotionAdapter.java,v $
   Revision 1.2  2005/01/05 09:22:27  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/04/23 10:02:49  bobintetley
   MouseEvent BUTTON_MASK constants, JSlider.createStandardLabels(), FontMetrics
   thread safety, Component/Toolkit.getFontMetrics() and MouseMotionAdapter


 */

package swingwt.awt.event;

public class MouseMotionAdapter implements MouseMotionListener {
    
    public void mouseDragged(MouseEvent e) {}    
    public void mouseMoved(MouseEvent e) {}
    
}
