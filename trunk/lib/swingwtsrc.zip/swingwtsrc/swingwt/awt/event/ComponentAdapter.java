/*
   SwingWT
   Copyright(c)2003-2005, Tomer Bartletz
 
   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.
 
   Contact me by electronic mail: tomerb@users.sourceforge.net

   $Log: ComponentAdapter.java,v $
   Revision 1.2  2005/01/05 09:22:26  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/03/30 14:22:27  bobintetley
   Fix to Component min/max sizing code, fix to JPanel insets with titled
   borders (all of which indirectly fix problems with BoxLayout). Addition
   of ComponentAdapter


 */
package swingwt.awt.event;

public class ComponentAdapter implements ComponentListener {
    public void componentHidden(ComponentEvent e) {}
    public void componentMoved(ComponentEvent e) {}
    public void componentResized(ComponentEvent e) {}
    public void componentShown(ComponentEvent e) {}
}
