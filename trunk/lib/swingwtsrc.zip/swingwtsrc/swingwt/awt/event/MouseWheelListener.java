/*
   SwingWT
   Copyright(c)2004, Daniel Naab

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: dannaab@users.sourceforge.net

   $Log: MouseWheelListener.java,v $
   Revision 1.1  2004/04/30 23:29:17  dannaab
   new mouse event/listener interfaces

 */

package swingwt.awt.event;

/**
 * MouseWheelListener
 *
 * @author  Naab
 * @version %I%, %G%
 */
public interface MouseWheelListener
{
    public void mouseWheelMoved(MouseWheelEvent e);
}
