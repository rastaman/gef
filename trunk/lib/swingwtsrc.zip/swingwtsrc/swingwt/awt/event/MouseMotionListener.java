/*
   SwingWT
   Copyright(c)2003-2005, Tomer Bartletz
 
   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.
 
   Contact me by electronic mail: tomerb@users.sourceforge.net

   $Log: MouseMotionListener.java,v $
   Revision 1.3  2005/01/05 09:22:27  bobintetley
   Updated copyright year on source

   Revision 1.2  2003/12/22 08:48:17  bobintetley
   Fixed up DnD to build temporarily


 */
package swingwt.awt.event;

import java.util.EventListener;

/**
 * 
 * 
 * @author Tomer Barletz, tomerb@users.sourceforge.net
 * @version 0.1
 */
public interface MouseMotionListener extends EventListener {
	
	public void mouseDragged(MouseEvent e);

	public void mouseMoved(MouseEvent e);
}
