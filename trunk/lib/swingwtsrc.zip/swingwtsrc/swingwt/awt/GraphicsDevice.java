/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley
 
   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.
 
   Contact me by electronic mail: bobintetley@users.sourceforge.net
 
   $Log: GraphicsDevice.java,v $
   Revision 1.4  2006/03/13 21:49:00  scytacki
   implemented getDefaultConfiguration

   Revision 1.3  2005/01/05 09:22:25  bobintetley
   Updated copyright year on source

   Revision 1.2  2004/04/20 15:11:25  bobintetley
   awt.MenuShortcut implementation


 */
package swingwt.awt;

/**
 * @author Daniel Spiewak
 */
public class GraphicsDevice {
	GraphicsConfiguration defaultConfig = new GraphicsConfiguration();

	public GraphicsConfiguration getDefaultConfiguration(){
		return defaultConfig;
	}
}

/*
 *****************************************************
 * Copyright 2003 Completely Random Solutions *
 *                                												*
 * DISCLAMER:                                 					*
 * We are not responsible for any damage      		*
 * directly or indirectly caused by the usage 			*
 * of this or any other class in assosiation  			*
 * with this class.  Use at your own risk.   			*
 * This or any other class by CRS is not   			*
 * certified for use in life support systems, 			*
 * the Space Shuttle, in use or developement  		*
 * of nuclear reactors, weapons of mass       		*
 * destruction, or in interplanitary conflict.				*
 * (Unless otherwise specified)               				*
 *****************************************************
 */