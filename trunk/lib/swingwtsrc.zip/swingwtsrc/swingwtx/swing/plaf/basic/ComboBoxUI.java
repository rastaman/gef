/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: ComboBoxUI.java,v $
   Revision 1.2  2005/01/05 09:22:34  bobintetley
   Updated copyright year on source

   Revision 1.1  2005/01/05 08:37:15  bobintetley
   Many compatibility fixes from David Barron

 
 */

package swingwtx.swing.plaf.basic;

import javax.swing.plaf.ComponentUI;

public class ComboBoxUI extends ComponentUI {

}
