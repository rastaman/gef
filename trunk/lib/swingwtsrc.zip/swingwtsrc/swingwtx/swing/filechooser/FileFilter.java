/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: FileFilter.java,v $
   Revision 1.3  2005/01/05 09:22:34  bobintetley
   Updated copyright year on source

   Revision 1.2  2003/12/14 09:13:39  bobintetley
   Added CVS log to source headers

*/

package swingwtx.swing.filechooser;

import java.io.*;

public abstract class FileFilter {
    public abstract boolean accept(File f);
    public abstract String getDescription(); 
}
