/*
   SwingWT
   Copyright(c)2003-2005 Daniel Naab

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: dannaab@users.sourceforge.net

   $Log: CannotRedoException.java,v $
   Revision 1.3  2005/01/05 09:22:37  bobintetley
   Updated copyright year on source

   Revision 1.2  2004/04/16 22:45:50  dannaab
   Add copyright msg

*/

package swingwtx.swing.undo;

/**
 * CannotRedoException
 *
 * @author  Naab
 * @version %I%, %G%
 */
public class CannotRedoException extends RuntimeException {}
