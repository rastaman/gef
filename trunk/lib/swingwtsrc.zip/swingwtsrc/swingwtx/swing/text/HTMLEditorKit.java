/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: HTMLEditorKit.java,v $
   Revision 1.2  2005/01/05 09:22:36  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/10/29 10:24:07  bobintetley
   Separate EditorPane implementations to decouple platform specifics,
   stubbing of HTMLEditorKit



*/

package swingwtx.swing.text;

public class HTMLEditorKit extends StyledEditorKit {
    
    public HTMLEditorKit() {
    }
    
}
