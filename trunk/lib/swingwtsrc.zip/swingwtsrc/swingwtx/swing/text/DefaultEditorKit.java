/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: DefaultEditorKit.java,v $
   Revision 1.3  2005/01/05 09:22:36  bobintetley
   Updated copyright year on source

   Revision 1.2  2004/09/01 23:20:19  dannaab
   TextAction stubbed; fix VK_UP/DOWN/etc mappings to SWT

   Revision 1.1  2004/01/27 09:39:30  bobintetley
   Text/Document support


*/

package swingwtx.swing.text;

public class DefaultEditorKit extends EditorKit {

    public static final String forwardAction = "caret-forward";
    public static final String backwardAction = "caret-backward";
    public static final String beginAction = "caret-begin";
    public static final String endAction = "caret-end";
    
    public Document createDefaultDocument() {
        return null;
    }    
    
    public swingwtx.swing.Action[] getActions() {
        return null;
    }
    
    public String getContentType() {
        return "text/plain";
    }
    
    public void read(java.io.InputStream in, Document doc, int pos) throws java.io.IOException, BadLocationException {
    }
    
    public void read(java.io.Reader in, Document doc, int pos) throws java.io.IOException, BadLocationException {
    }
    
    public void write(java.io.Writer out, Document doc, int pos, int len) throws java.io.IOException, BadLocationException {
    }
    
    public void write(java.io.OutputStream out, Document doc, int pos, int len) throws java.io.IOException, BadLocationException {
    }
    
}
