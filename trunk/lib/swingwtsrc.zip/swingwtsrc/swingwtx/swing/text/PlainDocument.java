/*
   SwingWT
   Copyright(c)2003-2005 Robin Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: PlainDocument.java,v $
   Revision 1.3  2005/01/05 09:22:36  bobintetley
   Updated copyright year on source

   Revision 1.2  2004/05/04 09:31:43  bobintetley
   PlainDocument/View support and implementation. Build script supports java/javax
   packages - fix to build script to use nested args in bootclasspath (single path broke on my Ant 1.6.1/Linux)

   Revision 1.1  2004/04/28 11:02:05  bobintetley
   PlainDocument implementation

*/

package swingwtx.swing.text;

/**
 * Plain Document implementation (default for JTextField, JPasswordField and
 * JTextArea)
 *
 * @author  Robin Rawson-Tetley
 */
public class PlainDocument extends AbstractDocument {
    
    public PlainDocument() { content = new GapContent(); }
    public PlainDocument(AbstractDocument.Content c) { content = c; }

    public Element getDefaultRootElement() {
        return null;
    }
    
    public Element getParagraphElement(int pos) {
        return null;
    }
    
}
