/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: Style.java,v $
   Revision 1.3  2005/01/05 09:22:36  bobintetley
   Updated copyright year on source

   Revision 1.2  2004/10/30 20:11:58  bobintetley
   Code cleanup

   Revision 1.1  2004/01/27 09:39:30  bobintetley
   Text/Document support


*/

package swingwtx.swing.text;

import swingwtx.swing.event.*;

public interface Style extends MutableAttributeSet {

    public String getName();
    public void addChangeListener(ChangeListener l);
    public void removeChangeListener(ChangeListener l);

}

