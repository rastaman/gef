/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: StyledEditorKit.java,v $
   Revision 1.3  2005/01/05 09:22:36  bobintetley
   Updated copyright year on source

   Revision 1.2  2004/11/10 14:20:49  bobintetley
   EditorKit support and DocumentEvents are now used to trigger updates

   Revision 1.1  2004/01/27 09:39:30  bobintetley
   Text/Document support


*/
package swingwtx.swing.text;

public class StyledEditorKit extends DefaultEditorKit {
    
	public Document createDefaultDocument() {
		return new DefaultStyledDocument();
	}
}
