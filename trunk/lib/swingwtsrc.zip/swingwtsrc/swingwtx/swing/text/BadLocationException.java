/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: BadLocationException.java,v $
   Revision 1.2  2005/01/05 09:22:36  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/01/26 08:11:14  bobintetley
   Many bugfixes and addition of SwingSet


*/
package swingwtx.swing.text;

public class BadLocationException extends Exception {
    public BadLocationException(String s, int offs) {
        super(s);
        this.offs = offs;
    }
    public int offsetRequested() {
        return offs;
    }
    private int offs;
}

