/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: JSeparator.java,v $
   Revision 1.8  2006/03/11 08:57:06  bobintetley
   (Scott Cytacki) Large patch containing Java2D implementation and some fixes

   Revision 1.7  2005/01/05 09:22:31  bobintetley
   Updated copyright year on source

   Revision 1.6  2004/01/20 09:17:15  bobintetley
   Menu class overhaul for compatibility, Action support and thread safety

   Revision 1.5  2003/12/15 18:29:57  bobintetley
   Changed setParent() method to setSwingWTParent() to avoid conflicts with applications

   Revision 1.4  2003/12/14 09:13:38  bobintetley
   Added CVS log to source headers

*/

package swingwtx.swing;

import org.eclipse.swt.widgets.*;
import org.eclipse.swt.*;

import swingwt.awt.Container;

public class JSeparator extends JSWTMenuComponent implements SwingConstants {
    
    private MenuItem mpeer = null;
    private Label    lpeer = null;
    private Shell shell = null;
    
    public JSeparator() { }
    public JSeparator(int orientation) {}
    
    public int getOrientation() { return HORIZONTAL; }
    public void setOrientation(int orientation) {}
    
    public void setSwingWTParent(Menu parent, Shell shell) throws Exception { 
        this.shell = shell;
        mpeer = new MenuItem(parent, SWT.SEPARATOR);
        peer = mpeer;
    }
    
    /**
     * JSeparators can be added inside of other containers too
     * @param parent
     * @param shell
     * @throws Exception
     */
    public void setSwingWTParent(Container parent, Shell shell) throws Exception { 
        this.shell = shell;
        lpeer = new Label(parent.getComposite(), SWT.SEPARATOR );
    }
 
    public boolean isSelected() {
        return false;
    }
    
    public void setSelected(boolean b) {
    }

    public void registerEvents() {
    	if(peer != null) {
    		super.registerEvents();
    	}
    }
    
    public void setCachedProperties() {
    	if(peer != null) {
    		super.setCachedProperties();
    	}
    }
    public void dispose() { 
    	if(peer != null) {
    		super.dispose();
    	}
    	
    	if(lpeer != null) {
            SwingUtilities.invokeSync(new Runnable() {
                public void run() {
                    if (SwingWTUtils.isSWTMenuControlAvailable(peer)) 
                        { lpeer.dispose(); lpeer = null; }
                }
             });
    		
    	}    	
   }

}
