/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley
 
   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.
 
   Contact me by electronic mail: bobintetley@users.sourceforge.net
 
   $Log: TableCellEditor.java,v $
   Revision 1.2  2005/01/05 09:22:36  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/04/16 14:39:03  bobintetley
   Table and Tree cell editor support

 
 */

package swingwtx.swing.table;

import swingwt.awt.*;
import swingwtx.swing.*;

public interface TableCellEditor extends CellEditor {

    Component getTableCellEditorComponent(JTable table, Object value,
					  boolean isSelected,
					  int row, int column);
}


