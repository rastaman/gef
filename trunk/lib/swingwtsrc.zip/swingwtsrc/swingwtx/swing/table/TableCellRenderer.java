/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: TableCellRenderer.java,v $
   Revision 1.4  2005/01/05 09:22:36  bobintetley
   Updated copyright year on source

   Revision 1.3  2003/12/14 09:13:39  bobintetley
   Added CVS log to source headers

*/

package swingwtx.swing.table;

import swingwtx.swing.*;
import swingwt.awt.*;

public interface TableCellRenderer {
    
     Component getTableCellRendererComponent(JTable table, Object value,
					    boolean isSelected, boolean hasFocus, 
					    int row, int column);    
}
