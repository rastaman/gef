/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net
 
   $Log: Icon.java,v $
   Revision 1.7  2005/01/05 09:22:30  bobintetley
   Updated copyright year on source

   Revision 1.6  2004/03/30 10:42:46  bobintetley
   Many minor bug fixes, event improvements by Dan Naab. Full swing.Icon support

 
*/
package swingwtx.swing;

import swingwt.awt.*;

/**
 * Now matches the Swing icon interface without
 * the need for the extraneous getImage() method.
 *
 * @author Bob Tetley
 */
public interface Icon {
    public int getIconHeight();
    public int getIconWidth();
    public void paintIcon(Component c, Graphics g, int x, int y);
}
