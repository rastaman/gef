/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley
 
   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.
 
   Contact me by electronic mail: bobintetley@users.sourceforge.net
 
   $Log: ExpandVetoException.java,v $
   Revision 1.2  2005/01/05 09:22:36  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/01/15 18:13:10  bobintetley
   TreeWillExpand support

 
 */

package swingwtx.swing.tree;

import swingwtx.swing.event.TreeExpansionEvent;

public class ExpandVetoException extends Exception {
    protected TreeExpansionEvent event;
    public ExpandVetoException(TreeExpansionEvent event) {
        this(event, null);
    }
    public ExpandVetoException(TreeExpansionEvent event, String message) {
        super(message);
        this.event = event;
    }
}
