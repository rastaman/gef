/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: RootPaneContainer.java,v $
   Revision 1.2  2005/01/05 09:22:32  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/03/22 15:10:22  bobintetley
   JRootPane and JLayeredPane implementation


*/

package swingwtx.swing;

import swingwt.awt.*;

public interface RootPaneContainer {
    
    JRootPane getRootPane();
    void setContentPane(Container contentPane);
    Container getContentPane();
    void setLayeredPane(JLayeredPane layeredPane);
    JLayeredPane getLayeredPane();
    void setGlassPane(Component glassPane);
    Component getGlassPane();

}
