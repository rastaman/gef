/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: ScrollPaneConstants.java,v $
   Revision 1.2  2005/01/05 09:22:32  bobintetley
   Updated copyright year on source

   Revision 1.1  2005/01/05 08:37:13  bobintetley
   Many compatibility fixes from David Barron

 
 */

package swingwtx.swing;

public interface ScrollPaneConstants {
    public static final int VERTICAL_SCROLLBAR_AS_NEEDED = 20;
    public static final int HORIZONTAL_SCROLLBAR_ALWAYS = 32;
    public static final int VERTICAL_SCROLLBAR_ALWAYS = 22;
    public static final int HORIZONTAL_SCROLLBAR_AS_NEEDED = 30;
}
