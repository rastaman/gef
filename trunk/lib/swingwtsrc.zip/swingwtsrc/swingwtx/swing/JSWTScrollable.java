/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: JSWTScrollable.java,v $
   Revision 1.8  2005/01/05 09:22:31  bobintetley
   Updated copyright year on source

   Revision 1.7  2004/04/23 09:40:15  bobintetley
   *** empty log message ***

   Revision 1.6  2004/04/23 09:38:35  bobintetley
   *** empty log message ***

   Revision 1.4  2004/01/27 09:05:11  bobintetley
   ListModel and List Selection implemented. ScrollPane fix so all components
      scrollable

   Revision 1.3  2003/12/14 09:13:38  bobintetley
   Added CVS log to source headers

*/

package swingwtx.swing;

public interface JSWTScrollable {

    void setHorizontalScrollPane(boolean b);
    void setVerticalScrollPane(boolean b);
    void setScrollPane(JScrollPane container);
}
