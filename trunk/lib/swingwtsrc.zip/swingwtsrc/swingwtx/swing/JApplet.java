/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley
 
   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.
 
   Contact me by electronic mail: bobintetley@users.sourceforge.net
 
   $Log: JApplet.java,v $
   Revision 1.4  2005/01/05 09:22:30  bobintetley
   Updated copyright year on source

   Revision 1.3  2005/01/05 08:37:13  bobintetley
   Many compatibility fixes from David Barron

   Revision 1.2  2004/03/22 15:28:52  bobintetley
   Complete stub Applet implementation

   Revision 1.1  2004/03/21 17:22:54  bobintetley
   Compatibility methods for awt Graphics, List and Label. Dummy Applet implementation

   
 */


package swingwtx.swing;

/**
 * Dummy JApplet class for Swing applet descendants.
 * Doesn't do anything as Applets are pretty
 * pointless under SwingWT (and unsupported).
 *
 * This is for those apps that have an Applet
 * and Frame interface (so they compile).
 *
 * @author Robin Rawson-Tetley
 */
public class JApplet extends swingwt.applet.Applet {

    public swingwt.awt.Container getContentPane() {
	return this;
    }

    public void setContentPane(swingwt.awt.Container pane) {	    
    }
    
}
