package swingwtx.swing;

import swingwt.awt.Image;
import swingwt.awt.image.RGBImageFilter;

public class GrayFilter extends RGBImageFilter {
	public static Image createDisabledImage(Image i) {
		throw new UnsupportedOperationException("");
	}
		
	public int filterRGB(int x, int y, int rgb) {
		// TODO Auto-generated method stub
		return 0;
	}

}
