/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: SwingConstants.java,v $
   Revision 1.8  2005/01/05 09:22:32  bobintetley
   Updated copyright year on source

   Revision 1.7  2004/10/30 20:11:57  bobintetley
   Code cleanup

   Revision 1.6  2004/05/06 12:35:22  bobintetley
   Parity with Swing constants for Binary Compatibility + fixes to JDesktopPane

   Revision 1.5  2004/01/20 14:22:49  bobintetley
   Trailing/Leading now mapped correctly

   Revision 1.4  2003/12/14 09:13:38  bobintetley
   Added CVS log to source headers

*/

package swingwtx.swing;

public interface SwingConstants {
    public static final int HORIZONTAL = 0;
    public static final int VERTICAL = 1; 
    public static final int CENTER = 0;
    public static final int TOP = 1;
    public static final int LEFT = 2;
    public static final int BOTTOM = 3;
    public static final int RIGHT = 4;
    public static final int NORTH = 1;
    public static final int NORTH_EAST = 2;
    public static final int EAST = 3;
    public static final int SOUTH_EAST = 4;
    public static final int SOUTH = 5;
    public static final int SOUTH_WEST = 6;
    public static final int WEST = 7;
    public static final int NORTH_WEST = 8;
    public static final int LEADING = 10;
    public static final int TRAILING = 11;
    public static final int NEXT = 12;
    public static final int PREVIOUS = 13;
}
