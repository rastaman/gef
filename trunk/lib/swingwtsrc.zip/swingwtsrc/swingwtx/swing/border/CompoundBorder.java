/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: CompoundBorder.java,v $
   Revision 1.5  2005/01/05 09:22:33  bobintetley
   Updated copyright year on source

   Revision 1.4  2004/10/30 20:11:57  bobintetley
   Code cleanup

   Revision 1.3  2003/12/14 09:13:38  bobintetley
   Added CVS log to source headers

*/

package swingwtx.swing.border;

public class CompoundBorder extends AbstractBorder implements Border {

    public CompoundBorder() {}
    public CompoundBorder(Border outsideBorder, Border insideBorder) {}

}
