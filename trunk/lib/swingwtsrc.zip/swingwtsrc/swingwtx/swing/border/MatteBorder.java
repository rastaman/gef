/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: MatteBorder.java,v $
   Revision 1.4  2005/01/05 09:22:33  bobintetley
   Updated copyright year on source

   Revision 1.3  2003/12/14 09:13:38  bobintetley
   Added CVS log to source headers

*/

package swingwtx.swing.border;

import swingwt.awt.*;
import swingwtx.swing.*;

public class MatteBorder extends AbstractBorder implements Border {
    public MatteBorder(int top, int left, int bottom, int right, Color matteColor) {}
    public MatteBorder(Insets borderInsets, Color matteColor) {}
    public MatteBorder(int top, int left, int bottom, int right, Icon tileIcon) {}
    public MatteBorder(Insets borderInsets, Icon tileIcon) {}
    public MatteBorder(Icon tileIcon) {}
}
