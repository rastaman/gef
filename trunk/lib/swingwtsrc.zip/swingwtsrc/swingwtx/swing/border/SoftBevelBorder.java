/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: SoftBevelBorder.java,v $
   Revision 1.5  2005/01/05 09:22:33  bobintetley
   Updated copyright year on source

   Revision 1.4  2003/12/15 15:54:25  bobintetley
   Additional core methods

   Revision 1.3  2003/12/14 09:13:38  bobintetley
   Added CVS log to source headers

*/

package swingwtx.swing.border;

import swingwt.awt.*;

public class SoftBevelBorder extends BevelBorder {
    public SoftBevelBorder(int bevelType) { this.bevelType = bevelType; }
    public SoftBevelBorder(int bevelType, Color highlight, Color shadow) { this(bevelType); }
    public SoftBevelBorder(int bevelType, Color highlightOuterColor, 
                       Color highlightInnerColor, Color shadowOuterColor, 
                       Color shadowInnerColor) { this(bevelType); }
}
