/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: LineBorder.java,v $
   Revision 1.4  2005/01/05 09:22:33  bobintetley
   Updated copyright year on source

   Revision 1.3  2003/12/14 09:13:38  bobintetley
   Added CVS log to source headers

*/

package swingwtx.swing.border;

import swingwt.awt.*;

public class LineBorder extends AbstractBorder implements Border {
    public static Border createBlackLineBorder() { return new LineBorder(Color.BLACK, 1); }
    public static Border createGrayLineBorder() { return new LineBorder(Color.GRAY, 1); }
    public LineBorder(Color color) {}
    public LineBorder(Color color, int thickness)  {}
    public LineBorder(Color color, int thickness, boolean roundedCorners)  {}
}
