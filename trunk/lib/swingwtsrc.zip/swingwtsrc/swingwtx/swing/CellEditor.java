/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley
 
   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.
 
   Contact me by electronic mail: bobintetley@users.sourceforge.net
 
   $Log: CellEditor.java,v $
   Revision 1.2  2005/01/05 09:22:30  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/04/16 14:38:47  bobintetley
   Table and Tree cell editor support

 
 */

package swingwtx.swing;

import java.util.*;
import swingwtx.swing.event.*;

public interface CellEditor {

    public Object getCellEditorValue();
    public boolean isCellEditable(EventObject anEvent);
    public boolean shouldSelectCell(EventObject anEvent);
    public boolean stopCellEditing();
    public void cancelCellEditing();
    public void addCellEditorListener(CellEditorListener l);
    public void removeCellEditorListener(CellEditorListener l);
}

