/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: SpinnerModel.java,v $
   Revision 1.2  2005/01/05 09:22:32  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/04/18 14:21:50  bobintetley
   JSpinner implementation


*/

package swingwtx.swing;

import swingwtx.swing.event.*;

public interface SpinnerModel 
{
    Object getValue();
    void setValue(Object value);
    Object getNextValue();
    Object getPreviousValue();
    void addChangeListener(ChangeListener l);
    void removeChangeListener(ChangeListener l);
}