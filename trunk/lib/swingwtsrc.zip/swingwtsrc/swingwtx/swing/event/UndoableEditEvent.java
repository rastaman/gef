/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: UndoableEditEvent.java,v $
   Revision 1.3  2005/01/05 09:22:34  bobintetley
   Updated copyright year on source

   Revision 1.2  2004/04/16 10:19:07  dannaab
   Misc bug fixes, InputMap implementation, preliminary undo support

   Revision 1.1  2004/01/26 08:11:00  bobintetley
   Many bugfixes and addition of SwingSet


*/

package swingwtx.swing.event;

import swingwtx.swing.undo.UndoableEdit;

public class UndoableEditEvent extends java.util.EventObject {
    private UndoableEdit myEdit;

    public UndoableEditEvent(Object source, UndoableEdit edit) {
        super(source);
        myEdit = edit;
    }

    public UndoableEdit getEdit() {
	    return myEdit;
    }
}
