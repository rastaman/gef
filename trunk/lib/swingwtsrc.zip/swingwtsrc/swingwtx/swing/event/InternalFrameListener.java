/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: InternalFrameListener.java,v $
   Revision 1.6  2005/01/05 09:22:33  bobintetley
   Updated copyright year on source

   Revision 1.5  2003/12/14 09:13:38  bobintetley
   Added CVS log to source headers

*/
package swingwtx.swing.event;


public interface InternalFrameListener {

    public void internalFrameActivated(InternalFrameEvent e);
    public void internalFrameClosed(InternalFrameEvent e);
    public void	internalFrameClosing(InternalFrameEvent e);
    public void	internalFrameDeactivated(InternalFrameEvent e);
    public void internalFrameDeiconified(InternalFrameEvent e);
    public void internalFrameIconified(InternalFrameEvent e);
    public void internalFrameOpened(InternalFrameEvent e);
    
}
