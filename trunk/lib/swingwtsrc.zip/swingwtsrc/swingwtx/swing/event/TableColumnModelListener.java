/*
   SwingWT
   Copyright(c)2003-2005, Tomer Bartletz
 
   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.
 
   Contact me by electronic mail: tomerb@users.sourceforge.net

   $Log: TableColumnModelListener.java,v $
   Revision 1.3  2005/01/05 09:22:33  bobintetley
   Updated copyright year on source

   Revision 1.2  2004/10/30 20:11:58  bobintetley
   Code cleanup

   Revision 1.1  2004/04/16 07:59:46  bobintetley
   New code for TableColumn events


 */

package swingwtx.swing.event;

public interface TableColumnModelListener {
    
    public void columnAdded(TableColumnModelEvent e);
    public void columnRemoved(TableColumnModelEvent e);
    public void columnMoved(TableColumnModelEvent e);
    public void columnMarginChanged(ChangeEvent e);
    public void columnSelectionChanged(ListSelectionEvent e);
}
