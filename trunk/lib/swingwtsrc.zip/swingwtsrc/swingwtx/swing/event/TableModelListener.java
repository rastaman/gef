/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: TableModelListener.java,v $
   Revision 1.5  2005/01/05 09:22:33  bobintetley
   Updated copyright year on source

   Revision 1.4  2003/12/14 09:13:38  bobintetley
   Added CVS log to source headers

*/

package swingwtx.swing.event;

public interface TableModelListener extends java.util.EventListener
{
    public void tableChanged(TableModelEvent e);
}
