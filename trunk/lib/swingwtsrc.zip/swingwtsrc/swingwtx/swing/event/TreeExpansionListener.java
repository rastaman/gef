/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: TreeExpansionListener.java,v $
   Revision 1.4  2005/01/05 09:22:33  bobintetley
   Updated copyright year on source

   Revision 1.3  2004/10/30 20:11:58  bobintetley
   Code cleanup

   Revision 1.2  2003/12/14 09:13:39  bobintetley
   Added CVS log to source headers

*/

package swingwtx.swing.event;

public interface TreeExpansionListener extends java.util.EventListener {
    
    public void treeExpanded(TreeExpansionEvent event);
    public void treeCollapsed(TreeExpansionEvent event);
    
}
