/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: ListDataEvent.java,v $
   Revision 1.2  2005/01/05 09:22:33  bobintetley
   Updated copyright year on source

   Revision 1.1  2003/12/15 17:37:18  bobintetley
   ComboBox model interfaces and support


*/

package swingwtx.swing.event;

public class ListDataEvent extends java.util.EventObject {
    
    private int type;
    private int index0;
    private int index1;
    
    public static final int CONTENTS_CHANGED = 0;
    public static final int INTERVAL_ADDED = 1;
    public static final int INTERVAL_REMOVED = 2;
    
    public int getType() { return type; }
    public int getIndex0() { return index0; }
    public int getIndex1() { return index1; }
    
    public ListDataEvent(Object source, int type, int index0, int index1) {
        super(source);
	this.type = type;
	this.index0 = index0;
	this.index1 = index1;
    }

}



