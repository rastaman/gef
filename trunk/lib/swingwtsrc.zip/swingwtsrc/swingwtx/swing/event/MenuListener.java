/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: MenuListener.java,v $
   Revision 1.2  2005/01/05 09:22:33  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/04/30 16:52:17  bobintetley
   MenuListener support, JViewport support, TreeSelectionModel stubs, additional JTree methods

*/

package swingwtx.swing.event;

public interface MenuListener extends java.util.EventListener {
    void menuSelected(MenuEvent e);
    void menuDeselected(MenuEvent e);
    void menuCanceled(MenuEvent e);
}

