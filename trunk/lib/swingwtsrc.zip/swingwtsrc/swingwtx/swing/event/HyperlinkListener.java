/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: HyperlinkListener.java,v $
   Revision 1.4  2005/01/05 09:22:33  bobintetley
   Updated copyright year on source

   Revision 1.3  2003/12/14 09:13:38  bobintetley
   Added CVS log to source headers

*/

package swingwtx.swing.event;


public interface HyperlinkListener extends java.util.EventListener {
    void hyperlinkUpdate(HyperlinkEvent e);
}

