/*
   SwingWT
   Copyright(c)2003-2005, Tomer Bartletz
 
   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.
 
   Contact me by electronic mail: tomerb@users.sourceforge.net

   $Log: TableColumnModelEvent.java,v $
   Revision 1.2  2005/01/05 09:22:33  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/04/16 07:59:46  bobintetley
   New code for TableColumn events


 */

package swingwtx.swing.event;

import swingwtx.swing.table.*;

import java.util.*;

public class TableColumnModelEvent extends EventObject {

    protected int fromIndex;
    protected int toIndex;

    public TableColumnModelEvent(TableColumnModel source, int from, int to) {
	super(source);
	fromIndex = from;
	toIndex = to;
    }
    public int getFromIndex() { return fromIndex; };
    public int getToIndex() { return toIndex; };
}

