/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: TabCloseListener.java,v $
   Revision 1.2  2005/01/05 09:22:29  bobintetley
   Updated copyright year on source

   Revision 1.1  2004/01/20 07:38:05  bobintetley
   Bug fixes and compatibility methods

   Revision 1.2  2003/12/14 09:13:38  bobintetley
   Added CVS log to source headers

*/

package swingwtx.custom.event;

/** Not a real Swing event, but part of my JClosableTabbedPane
 *  for use by MDI apps
 */
public interface TabCloseListener extends java.util.EventListener
{
    /** Fired when a tab is closed. Return a true value
     *  if you want the tab closed in your event handler */
    public boolean tabClosed(int index);
}
