/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley
 
   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.
 
   Contact me by electronic mail: bobintetley@users.sourceforge.net
 
   $Log: AccessibleContext.java,v $
   Revision 1.3  2005/01/05 09:22:29  bobintetley
   Updated copyright year on source

   Revision 1.2  2004/04/15 09:27:26  bobintetley
   Accessibility/Component UI stuff (Dan Naab)

   Revision 1.1  2004/02/19 10:01:30  bobintetley
   Stubbed version for GCJ compatibility

 */

package swingwtx.accessibility;

import swingwt.awt.IllegalComponentStateException;

import java.beans.PropertyChangeListener;
import java.util.Locale;

/**
 * TODO: Implement
 * @author  Naab
 * @version %I%, %G%
 */
public abstract class AccessibleContext
{
    /** abstract method definitions */
    public abstract int getAccessibleIndexInParent();
    public abstract int getAccessibleChildrenCount();
    public abstract Accessible getAccessibleChild(int i);
    public abstract Locale getLocale() throws IllegalComponentStateException;

    public String getAccessibleName() { return null; }
    public void setAccessibleName(String s) {}
    public String getAccessibleDescription() { return null; }
    public void setAccessibleDescription(String s) {}
    public abstract AccessibleRole getAccessibleRole();
    public abstract AccessibleStateSet getAccessibleStateSet();
    public Accessible getAccessibleParent() { return null; }
    public void setAccessibleParent(Accessible a) {}

    /** TODO: Implement PropertyChange support */
    public void addPropertyChangeListener(PropertyChangeListener listener) {}
    public void removePropertyChangeListener(PropertyChangeListener listener) {}
    public void firePropertyChange(String propertyName, Object oldValue, Object newValue) {}

    public AccessibleAction getAccessibleAction() { return null; }
    public AccessibleComponent getAccessibleComponent() { return null; }
    public AccessibleSelection getAccessibleSelection() { return null; }
    public AccessibleText getAccessibleText() { return null; }
    public AccessibleEditableText getAccessibleEditableText() { return null; }
    public AccessibleValue getAccessibleValue() { return null; }
    public AccessibleIcon[] getAccessibleIcon() { return null; }
    public AccessibleRelationSet getAccessibleRelationSet() { return null; }
    public AccessibleTable getAccessibleTable() { return null; }
}
