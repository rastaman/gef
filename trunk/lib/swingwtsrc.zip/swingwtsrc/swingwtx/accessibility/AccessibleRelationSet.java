/*
   SwingWT
   Copyright(c)2003-2005, R. Rawson-Tetley

   For more information on distributing and using this program, please
   see the accompanying "COPYING" file.

   Contact me by electronic mail: bobintetley@users.sourceforge.net

   $Log: AccessibleRelationSet.java,v $
   Revision 1.3  2005/01/05 09:22:29  bobintetley
   Updated copyright year on source

   Revision 1.2  2004/04/15 11:24:32  bobintetley
   (Dan Naab) ComponentUI, UIDefaults/UIManager and Accessibility support.
   (Antonio Weber) TableColumnModelListener implementation and support


*/

package swingwtx.accessibility;

/**
 * TODO: Implement
 * @author  Naab
 * @version %I%, %G%
 */
public class AccessibleRelationSet
{
}
